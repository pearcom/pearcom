<?php
/**
 * Created by JetBrains PhpStorm.
 * User: klug
 * Date: 24.11.12
 * Time: 23:30
 * To change this template use File | Settings | File Templates.
 */
class catalog_controller_index extends klug_controller_abstract
{
    public function indexAction()
    {
        $model =  new catalog_model_category();
        $this->_view->set('module',$model->loadAllArray());
    }


}
