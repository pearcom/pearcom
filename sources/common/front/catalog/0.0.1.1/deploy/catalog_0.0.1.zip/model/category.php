<?php
/**
 * Created by JetBrains PhpStorm.
 * User: klug
 * Date: 07.12.12
 * Time: 23:45
 * To change this template use File | Settings | File Templates.
 */
class catalog_model_category extends klug_client_abstract
{
    public function load($id)
    {
        $this->_data = $this->_model->load($id);
    }
    public function loadAll()
    {
        return $this->_model->loadAll();
    }

    public function loadAllArray()
    {
        return $this->_model->loadAllArray();
    }

    public function getData($name = null)
    {
        if(!$name)
        {
            return $this->_data;
        }
        return $this->_data[$name];
    }

}
