<?php
/**
 * Created by JetBrains PhpStorm.
 * User: klug
 * Date: 07.12.12
 * Time: 23:45
 * To change this template use File | Settings | File Templates.
 */
class products_model_product extends klug_client_abstract
{
    protected $_data;

    public function load($id)
    {
        $this->_data = $this->_model->load('storeid',$id);
    }

    public function getData($name)
    {
        return $this->_data[$name];
    }
}
