<?php
/**
 * Created by JetBrains PhpStorm.
 * User: klug
 * Date: 24.11.12
 * Time: 23:30
 * To change this template use File | Settings | File Templates.
 */
class products_controller_index extends klug_controller_abstract
{
    public function indexAction()
    {
        $model =  new products_model_product();
        $model->load(5);
        $this->_view->set('name',$model->getData("name"));

    }


}
